/* --------------------------------------------------------------
   Application: 04 - Rev1
   Class: Real Time Systems - Su 2025
   Author: [A Barrass] 
   Email: [al855321@ucf.edu]
   This system will monitor a radiation reader ran on a potentiometer scale in order to 
   meticulously update and report read values while keeping a threshold in mind and alerting when said
   threshold is exceeded or when the manual button alert is triggered.
---------------------------------------------------------------*/

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "driver/adc.h"
#include "esp_log.h"

#define LED_GREEN GPIO_NUM_5
#define LED_RED   GPIO_NUM_4
#define BUTTON_PIN GPIO_NUM_18
#define POT_ADC_CHANNEL ADC1_CHANNEL_6 // GPIO34

#define MAX_COUNT_SEM 30
#define SENSOR_THRESHOLD 3100

SemaphoreHandle_t sem_button;
SemaphoreHandle_t sem_sensor;
SemaphoreHandle_t print_mutex;

volatile int SEMCNT = 0;

void heartbeat_task(void *pvParameters) {
    while (1) {
        gpio_set_level(LED_GREEN, 1);
        vTaskDelay(pdMS_TO_TICKS(1000));
        gpio_set_level(LED_GREEN, 0);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}


void sensor_task(void *pvParameters) {
  int last_state = 0; //rising-edge
    while (1) {
        int val = adc1_get_raw(POT_ADC_CHANNEL);

        xSemaphoreTake(print_mutex, portMAX_DELAY);
        printf("Radiation Level: %d\n", val);
        xSemaphoreGive(print_mutex);
        
        //printf("Value: %d\n", val); redundant
        if (val > SENSOR_THRESHOLD && !last_state) {
            //printf("WARNING RADIATION THRESHOLD EXCEEDED\n");
            if(SEMCNT < MAX_COUNT_SEM+1) SEMCNT++; 
            xSemaphoreGive(sem_sensor);
        }
        last_state = (val > SENSOR_THRESHOLD);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}


void button_task(void *pvParameters) {
    uint32_t last_press_time = 0;
    while (1) {
        int state = gpio_get_level(BUTTON_PIN);
        if (state == 0 && (xTaskGetTickCount() - last_press_time) > pdMS_TO_TICKS(500)){
          xSemaphoreGive(sem_button);
          xSemaphoreTake(print_mutex, portMAX_DELAY);
          //printf("MANUAL ALERT NOTIFICATION!\n");
          xSemaphoreGive(print_mutex);

          last_press_time = xTaskGetTickCount();
        }
        vTaskDelay(pdMS_TO_TICKS(10)); // Do Not Modify This Delay!
    }
}

void event_handler_task(void *pvParameters) {
    while (1) {
        if (xSemaphoreTake(sem_sensor, 0)) {
            SEMCNT--;  // DO NOT MODIFY THIS LINE

            xSemaphoreTake(print_mutex, portMAX_DELAY);
            printf("Radiation Alert! Exceeded Safe Exposure Limits!\n");
            xSemaphoreGive(print_mutex);

            gpio_set_level(LED_RED, 1);
            vTaskDelay(pdMS_TO_TICKS(1000));
            gpio_set_level(LED_RED, 0);
        }

        if (xSemaphoreTake(sem_button, 0)) {
            xSemaphoreTake(print_mutex, portMAX_DELAY);
            printf("MANUAL RADIATION ALERT TRIGGERED!\n");
            xSemaphoreGive(print_mutex);

            gpio_set_level(LED_RED, 1);
            vTaskDelay(pdMS_TO_TICKS(5000));
            gpio_set_level(LED_RED, 0);
        }

        vTaskDelay(pdMS_TO_TICKS(10)); // Idle delay to yield CPU
    }
}

void app_main(void) {
    // Configure output LEDs
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << LED_GREEN) | (1ULL << LED_RED),
        .mode = GPIO_MODE_OUTPUT,
    };
    gpio_config(&io_conf);

    // Configure input button
    gpio_config_t btn_conf = {
        .pin_bit_mask = (1ULL << BUTTON_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE
    };
    gpio_config(&btn_conf);

    // Configure ADC
    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(POT_ADC_CHANNEL, ADC_ATTEN_DB_11);

    //primitives
    sem_button = xSemaphoreCreateBinary();
    sem_sensor = xSemaphoreCreateCounting(MAX_COUNT_SEM, 0);
    print_mutex = xSemaphoreCreateMutex();
 


    //TODO 5: Test removing the print_mutex around console output (expect interleaving)
    //Observe console when two events are triggered close together

    // Create tasks
    xTaskCreate(heartbeat_task, "heartbeat", 2048, NULL, 1, NULL);
    xTaskCreate(sensor_task, "sensor", 2048, NULL, 2, NULL);
    xTaskCreate(button_task, "button", 2048, NULL, 3, NULL);
    xTaskCreate(event_handler_task, "event_handler", 2048, NULL, 2, NULL);

    //TODO 6: Experiment with changing task priorities to induce or fix starvation
    //E.G> Try: xTaskCreate(sensor_task, ..., 4, ...) and observe heartbeat blinking
    //You should do more than just this example ...
}
